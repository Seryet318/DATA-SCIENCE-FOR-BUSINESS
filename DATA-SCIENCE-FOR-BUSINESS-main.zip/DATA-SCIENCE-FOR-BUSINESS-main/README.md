# DATA-SCIENCE-FOR-BUSINESS

Dowload the 2 dataset for the officil Lombardia web site
  - https://www.dati.lombardia.it/Attivit-Produttive/Rapporti-di-lavoro-attivati/qbau-cyuc 
  - https://www.dati.lombardia.it/Attivit-Produttive/Rapporti-di-lavoro-cessati/nwz3-p6vm

Open the folder "GuanettiAlicemat738422_MacchiDanielemat731008_Lab01" in order to view the 3 files that contains the data sets analisys.

Open the "GuanettiAlicemat738422_MacchiDanielemat731008_Lavori_Attivati" in order to view the analysis of the "Rapporti_di_lavoro_attivati" data set.

Open the "GuanettiAlicemat738422_MacchiDanielemat731008_Lavori_Cessati" in order to view the analysis of the "Rapporti_di_lavoro_cessati" data set.

Open the "GuanettiAlicemat738422_MacchiDanielemat731008_Global" in order to view the comparison analysis of the first and the second data set.

The folder "Graph Analysis" contains all the graph images

